
#Definir una clase Cliente que almacene un código de cliente, cedula, nombre, direccion y fecha Nacimiento.  En la clase Cliente definir una variable de clase de tipo lista que almacene todos los clientes que tienen suspendidas sus cuentas de ahorro.  Imprimir por pantalla todos los datos de clientes y el estado que se encuentra su cuenta de ahorro.
sueldos = 1000
clase = []
class cliente:
    def __init__(self):
        self.codigo=int(input("Ingrese su codigo: "))
        clase.append(self.codigo)
        self.cedula=int(input("Ingrese su cedula: "))
        clase.append(self.cedula)
        self.nombre=input("Ingrese su nombre: ")
        clase.append(self.nombre)
        self.dirrecion=input("ingrese su direccion: ")
        clase.append(self.dirrecion)
        self.fecha=int(input("Ingrese su fecha: "))
        clase.append(self.fecha)
    
class Empleado(cliente):
    def __init__(self):
        super().__init__()
        self.sueldo=float(input("Cuanto desea gastar: "))
    def pagar_impuestos(self):
        if self.sueldo > sueldos:
            print(clase)
            print(f"{self.nombre} has gastado mas de la cuenta por lo tanto su cuenta has sido suspendida.")
        else:
            print(f"{self.nombre} le queda dinero para gastar.")
 

empleado1=Empleado()
empleado1.pagar_impuestos()
persona1=cliente()


